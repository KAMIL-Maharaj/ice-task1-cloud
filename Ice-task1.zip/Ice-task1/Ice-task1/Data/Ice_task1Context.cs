﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using Ice_task1.Models;

namespace Ice_task1.Data
{
    public class Ice_task1Context : DbContext
    {
        public Ice_task1Context (DbContextOptions<Ice_task1Context> options)
            : base(options)
        {
        }

        public DbSet<Ice_task1.Models.Cars> Cars { get; set; } = default!;
    }
}
