﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
namespace Ice_task1.Models
{
    public class Cars
    {

        public int Id { get; set; }
        public string? Car { get; set; }
        [Display(Name = "top speed km/ph")]
        public string? top_speed { get; set; }
        [Column(TypeName = "decimal(18, 2)")]
        public decimal Price { get; set; }
    }
}
