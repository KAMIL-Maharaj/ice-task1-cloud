﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using Ice_task1.Data;
using Ice_task1.Models;

namespace Ice_task1.Pages.cars
{
    public class IndexModel : PageModel
    {
        private readonly Ice_task1.Data.Ice_task1Context _context;

        public IndexModel(Ice_task1.Data.Ice_task1Context context)
        {
            _context = context;
        }

        public IList<Cars> Cars { get;set; } = default!;

        public async Task OnGetAsync()
        {
            Cars = await _context.Cars.ToListAsync();
        }
    }
}
