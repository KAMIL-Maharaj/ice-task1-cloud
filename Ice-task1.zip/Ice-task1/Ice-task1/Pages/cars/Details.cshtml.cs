﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using Ice_task1.Data;
using Ice_task1.Models;

namespace Ice_task1.Pages.cars
{
    public class DetailsModel : PageModel
    {
        private readonly Ice_task1.Data.Ice_task1Context _context;

        public DetailsModel(Ice_task1.Data.Ice_task1Context context)
        {
            _context = context;
        }

        public Cars Cars { get; set; } = default!;

        public async Task<IActionResult> OnGetAsync(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var cars = await _context.Cars.FirstOrDefaultAsync(m => m.Id == id);
            if (cars == null)
            {
                return NotFound();
            }
            else
            {
                Cars = cars;
            }
            return Page();
        }
    }
}
